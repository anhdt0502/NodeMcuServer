AmCharts.translations.dataLoader.en = {
  'Error loading the file': 'Error loading the file',
  'Error parsing JSON file': 'Error parsing JSON file',
  'Unsupported data format': 'Unsupported data format',
  'Loading data...': 'Loading data...'
}