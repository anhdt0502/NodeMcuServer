/*
 Template Name: Urora - Bootstrap 4 Admin Dashboard
 Author: Mannatthemes
 Website: www.mannatthemes.com
 File: other. Js
 */


!function($) {
    "use strict";

    $(function() {
        $(".knob").knob();
    });

}(window.jQuery);



