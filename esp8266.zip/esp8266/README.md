# Giới thiệu

Chương trình dùng để tạo một socketServer
Hãy tham khảo bài viết để biết thêm chi tiết tại http://arduino.vn/bai-viet/1496-esp8266-ket-noi-internet-phan-1-cai-dat-esp8266-lam-mot-socket-client-ket-noi-toi